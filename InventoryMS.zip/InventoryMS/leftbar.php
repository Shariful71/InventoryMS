<h5 class="bg-success text-white px-2 py-1">Category</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="add_category.php" class="text-dark text-decoration-none">Add Category</a>
							</li>
							<li class="list-group-item">
								<a href="list_of_category.php" class="text-dark text-decoration-none">Category List</a>
							</li>
						</ul>
						<h5 class="bg-success text-white px-2 py-1">Product</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="add_product.php" class="text-dark text-decoration-none">Add Product</a>
							</li>
							<li class="list-group-item">
								<a href="list_of_product.php" class="text-dark text-decoration-none">Product List</a>
							</li>
						</ul>
						<h5 class="bg-success text-white px-2 py-1">Store Product</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="add_store_product.php" class="text-dark text-decoration-none">Add Store Product</a>
							</li>
							<li class="list-group-item">
								<a href="list_of_entry_product.php" class="text-dark text-decoration-none">Store Product List</a>
							</li>
						</ul>
						<h5 class="bg-success text-white px-2 py-1">Spend Product</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="add_spend_product.php" class="text-dark text-decoration-none">Add Spend Product</a>
							</li>
							<li class="list-group-item">
								<a href="list_of_spend_product.php" class="text-dark text-decoration-none">Spend Product List</a>
							</li>
						</ul>
						<h5 class="bg-success text-white px-2 py-1">Report</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="report.php" class="text-dark text-decoration-none">Report</a>
							</li>
						</ul>
						<h5 class="bg-success text-white px-2 py-1">Users</h5>
						<ul class="list-group m-2">
							<li class="list-group-item">
								<a href="add_users.php" class="text-dark text-decoration-none">Add User</a>
							</li>
							<li class="list-group-item">
								<a href="list_of_users.php" class="text-dark text-decoration-none">User's List</a>
							</li>
						</ul>